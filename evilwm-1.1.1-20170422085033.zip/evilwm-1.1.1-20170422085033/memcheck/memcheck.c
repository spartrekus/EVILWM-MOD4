
#include <stdio.h> 
#include <stdlib.h> 

int main(){ 
    printf( "MEMCHECK: ");
    system( " ps aux --sort pmem | grep evilwm " );
    return 0; 
}  


